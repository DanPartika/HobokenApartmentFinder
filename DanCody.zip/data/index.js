const apartmentData = require("./apartments");
const reviewData = require("./reviews");
const usersData = require("./users");


module.exports = {
  apartments: apartmentData,
  review: reviewData,
  users: usersData
};
